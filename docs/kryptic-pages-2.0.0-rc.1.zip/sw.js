const CACHE = "kryptic-shell-63ed56ef0693";
const ASSETS = ["/","/index.html","/manifest.json","/icon-192.png","/icon-512.png","/static/css/main.c5afdd9c.css","/static/js/main.f07d98a8.js"];
const CACHEABLE = ["/onnx/ort-wasm-simd-threaded.jsep.mjs","/onnx/ort-wasm-simd-threaded.jsep.wasm","/static/css/main.c5afdd9c.css","/static/js/main.f07d98a8.js","/static/js/612.198f3939.chunk.js","/static/js/43.9f2a28a1.chunk.js","/static/js/52.f6c03db8.chunk.js","/static/js/82.12ac0880.chunk.js","/static/js/239.69bdfee3.chunk.js","/static/js/666.98c35064.chunk.js","/static/media/ort-wasm-simd-threaded.jsep.666d0398a1e13e9c0c1d.wasm","/static/media/ort.bundle.min.a2871ea7770c10e138c0.mjs","/index.html"];
self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith("kryptic-shell-") && key !== CACHE).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET" || new URL(request.url).origin !== self.location.origin) return;
  if (request.mode === "navigate") {
    event.respondWith(fetch(request).catch(() => caches.match("/index.html")));
    return;
  }
  if (CACHEABLE.includes(new URL(request.url).pathname)) {
    event.respondWith(caches.open(CACHE).then(async (cache) => {
      const cached = await cache.match(request);
      if (cached) return cached;
      const response = await fetch(request);
      if (response.ok) await cache.put(request, response.clone());
      return response;
    }));
  }
});
